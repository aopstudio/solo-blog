title: 使用nginx和tomcat配置反向代理和动静分离
date: '2019-03-03 18:23:41'
updated: '2019-03-03 18:23:41'
tags: [nginx, tomcat, 动静分离, 反向代理]
permalink: /articles/2019/03/03/1551608135865.html
---
## 背景
本人主修的编程语言是Java语言，因此最开始接触的Web开发也是JSP技术。使用Java开发的Web应用需要部署在专门的服务器程序上运行，比如Tomcat。但是一般很少会有人将Tomcat作为用户直接访问的服务器的，一般都是使用nginx或者Apache进行反向代理。我使用的是nginx。nginx是一个俄罗斯程序员开发的服务器程序，它本身只能提供静态资源的服务，但它的优点在于并发访问量可以达到非常大的水平。

## 反向代理的优点
反向代理的主要优点是提高并发访问数。单独一个Tomcat服务器能提供的并发访问数不高，如果在主机上部署多个Tomcat服务器，使用nginx进行反向代理，动态调整用户的请求到不同的Tomcat服务器（这个过程称为负载均衡），就可以使并发访问量和单个Tomcat服务器相比得到成倍的提升。

动静资源分离也常常和反向代理在一起被提起，比如你部署了一个Java Web应用，这是一个动态资源，需要Tomcat提供服务（由反向代理实现），但你的网站上同时还有其他的比如纯HTML的网页、图片等等静态资源，这些静态资源就可以由nginx直接提供给访问者，减少了调用Tomcat而产生的多余资源消耗，同样静态资源可以获得相当大的一个并发访问量。


可以画一张图来更清晰地表明反向代理的工作流程。

1. 用户请求动态资源
![反向代理.png](https://img.hacpai.com/file/2019/03/反向代理-76adf9e3.png)
2. 用户请求静态资源
![动静分离.png](https://img.hacpai.com/file/2019/03/动静分离-22d842f2.png)


## 具体配置方法
配置的方法有很多，我以我自己的实现方法来进行讲解。

首先找到nginx的配置文件nginx.conf。如果是使用yum安装的nginx那么它的默认路径是在/etc/nginx/中。在该文件中找到：
```conf
server {
        listen       80;  
        server_name  localhost;

        location / {
            root   /user/share/nginx/html;
            index  index.html index.htm;
        }  

        ……
```
也有可能和上述内容有些许不同，重点是`listen 80`，只要找到它，就确定了位置。

80端口一般代表http协议，也就是我们在浏览器上输入网址或者IP地址时默认使用的访问协议。`server_name`用于配置虚拟主机，我们现在暂时用不到。重点在`location`。location后面代表访问的虚拟目录，`/`代表根目录，，也就是直接输入域名或IP地址访问的目录，以本地主机为例，就是直接在浏览器里输入127.0.0.1。在location的大括号里面，root代表的是虚拟目录映射在本地主机上的实际目录,如果是使用yum方式安装的nginx，那么它的默认访问目录是`/user/share/nginx/html`。index后面代表的是该目录的首页文件，像示例中就设定了首页文件为index.html或者index.htm。

假如我们要用nginx反向代理tomcat，并且希望在浏览器直接输入`主机的IP地址`时访问到nginx默认的首页，而输入`主机的IP地址/tomcat`时访问到tomcat上的内容，我们就要这样配置。
```conf
server {
        listen       80;  
        server_name  localhost;

        location / {
            root   /user/share/nginx/html;
            index  index.html index.htm;
        }  

        location /tomcat {
            proxy_pass   http://127.0.0.1:8080;
        }
        ……
```

加上去的内容就相当于告诉nginx，在用户访问`IP地址/tomcat`时，就将访问请求传递到8080端口（因为tomcat默认运行在8080端口，如果修改过tomcat默认运行端口，就将8080改成修改后的端口号）。

这样配置完成后，我们就同时实现了动静资源分离和反向代理。直接访问`IP地址`时，nginx给用户的是静态资源，减小计算资源的消耗，访问`IP地址/tomcat`时则由tomcat提供服务，实现了反向代理。

上面讲的是最基本的配置反向代理和动静分离的方法，还有更加高级的方法，比如设置不同的三级域名访问到不同的目录，动静分离特定格式的文件等等。在此我不做展开，大家有兴趣可以去网上寻找其他资料。