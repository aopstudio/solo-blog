title: 本博客启用https的过程
date: '2019-02-07 17:15:48'
updated: '2019-02-28 18:15:44'
tags: [SSL证书, https, nginx, 阿里云]
permalink: /articles/2019/02/03/1549163941555.html
---
## 申请SSL证书
我的博客部署在阿里云服务器上，因此我就先搜索阿里云启用https的方法，网上有比较详细的讲解，在此提供一个参考网址：
[https://blog.csdn.net/cslucifer/article/details/79077831](https://blog.csdn.net/cslucifer/article/details/79077831)  

## 修改nginx配置文件
我的博客设置了nginx作为前置服务器反向代理Tomcat的内容，因此需要配置的是nginx的证书而不是Tomcat的。我看了一下阿里云官方文档中证书下载页的详情文档，nginx的配置方法比Tomcat简单很多，哈哈，看来真是一个明智的选择。

这个时候出现了一个问题，我找不到nginx的配置文件`nginx.conf`了。按照网上说的nginx安装目录死活找不到。没办法，只能动用Linux的查找文件的功能了。Linux有若干个不同的查找文件的方法。其中`find`是最简单粗暴的命令，就是在指定目录中一个个地找，速度比较慢。另一个命令是`locate`，它的执行速度很快，因为是在建立了文件索引的数据库中查找。我之前并没有使用过`locate`命令，只是在书上看到过，这次是第一次实际操作。当我输入`locate nginx.conf`时，意想不到的情况出现了，系统报告不存在locate命令。没办法，又只能问搜索引擎到底怎么回事。结果别人也有遇到这种情况的，貌似是CentOS 7以上版本不自带locate命令，解决方法如下：输入`yum install mlocate`以安装相关内容。之后更新一下数据库，输入`updatedb`。安装完locate功能之后，再查找nginx的配置文件，非常轻松的找到了。
找到配置文件后，修改nginx配置文件中的
```conf
# HTTPS server
#
# server {
# balabala
# }
```

变为
```conf
# HTTPS server
#
server {
	listen 443;
	server_name localhost;
	ssl on;
	root html;
	index index.html index.htm;
	ssl_certificate   pem文件路径;
	ssl_certificate_key  key文件路径;
	ssl_session_timeout 5m;
	ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE:ECDH:AES:HIGH:!NULL:!aNULL:!MD5:!ADH:!RC4;
	ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
	ssl_prefer_server_ciphers on;
	location / {
	 root html;
	 index index.html index.htm;
	 proxy_pass http://127.0.0.1:8080/;
	}
}
```
这样就可以开启https访问了。

## 强制使用https连接
不过还有一个问题，就是当用户输入不带协议名的域名时，依然选择HTTP连接。接下来我们要做的是强制使用https连接。网上有几种不同的解决方法，其中最简单的一种，是使用rewrite。依然是在nginx配置文件中，找到
```conf
server {
        listen       80;
        server_name  localhost;
```
在`server_name localhost;`后面加上一行：`rewrite ^(.*)$  https://$host$1 permanent; `。这样当用户输入不带协议名的域名时，也能自动选择https进行连接。

## 后记 小锁真漂亮
成功配置完https之后，使用浏览器访问我的博客时，地址栏会显示一把代表安全连接的小锁，而不是之前的不安全提示
[![https.png](https://i.postimg.cc/L5nhRFQ4/https.png)](https://postimg.cc/9wHctKjs)
之前也没感觉什么，自己配置成功后感觉这小锁可真漂亮啊。