title: VB.NET学习体会
date: '2018-12-08 18:39:24'
updated: '2019-02-28 18:13:29'
tags: [学习体会]
permalink: /articles/2018/12/08/1544265564840.html
---
**注：本文写于2018年01月28日，首先发表于CSDN博客“aopstudio的博客”上**

---
下学期要学习VB.NET程序设计课程，这几天在家开始自习。在自习的过程中发现VB.NET和Java以及C语言有很大的不同，在这里总结一下到目前为止的成果。以后还会逐渐更新。

---
首先最大的不过也是最不重要的一个不同点就是VB每条语句不需要用分号结尾。一开始写程序的时候习惯性地就会在语句末尾加上一个分号`;`，结果就报错了。但习惯了以后就好，而且如果加了分号是不可能编译通过的，俗话说得好：**能在编译时找到的问题都不是问题**，所以称它为最不重要的。

---
&emsp;&emsp;C和Java都用大括号`{}`来表示语句块。但VB不是，它使用的是End。就说main函数吧。
C语言这样写：
```c
int main(void)
{
	//函数体
}
```
Java这样：
```java
public static void main(String[] args){
	//函数体
}
```
而VB这样写：
```vbnet
Sub Main()
	'函数体
End Sub
```

---

粗略地分来，函数（或者叫方法）可以分为两大类，一种是有返回值的，一个是没有返回值的。Java和C语言的处理方法类似，都采用void表示无返回值。但VB就不同了，根据我目前的了解，它采用Sub和Function这两个关键词分别代表无返回值和有返回值。而且返回的方法除了使用return外，还可以把要返回的值赋给函数名。例：

```
Function Plus(a As Integer)
    Plus = a + 1
End Function
```
上面这个函数就返回了参数加1之后的值。
提到函数，相信有人就会想到形参和实参的问题，也就是传值调用和引用调用的问题。在C语言中这是个需要用到指针解决的问题；Java则作了区分：基本数据类型是传值调用，对象引用类型是传引用。VB则用关键字来解决这个问题：ByVal代表传值调用，ByRef代表引用调用。例：
主函数都相同：

```vbnet
Sub Main()
    Dim a As Integer = 1
    Console.WriteLine(a)
    Console.WriteLine(Plus(a))
    Console.WriteLine(a)
End Sub
```
Plus函数如下:
(1)
```vbnet
'引用调用版本
Function Plus(ByRef a as Integer)
	Plus=a+1
End Function
```
它的输出是：
```
1
2
2
```
(2)
```vbnet
'传值调用版本
Function Plus(ByVal a as Integer)
	Plus=a+1
End Function
```
它的输出是：
```
1
2
1
```
ByVal和ByRef是可以省略不写的。在VB6以及之前的版本中，默认采用的是ByRef方式，在之后的版本中采用的是ByVal的方式。

---
接下来要说的是VB的数组。和C语言以及Java语言不同，它是用圆括号而不是方括号定义的，而且元素数量也不同，会比Java多一个。*Talk is cheap, show me the code. *接下来就给出一个例子。
```vbnet
Dim a(10) As Integer
```
这句代码就定义了一个含有11个元素（a(0)到a(10)）的整型数组。同时也发现，VB会对数组是否越界进行检查，但不会在编译时提示，而是在运行时控制台中给出提示。我们接着上面的代码继续往下写

```vbnet
a(11) = 1
Console.WriteLine(a(11))
```
产生的结果如下

![VB数组越界](https://img-blog.csdn.net/20180128191416688?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvYW9wc3R1ZGlv/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)

---
再来说说VB的循环以及和循环相关的一些内容。首先说说for循环吧。使用for循环打印出1到9，Java这样写：

```java
for(int i=0;i<10;i++){
	System.out.println(i);
}
```
VB这样写：
```vbnet
Dim i as Integer
For i=0 To 9
	Console.WriteLine(i)
Next
```
看到i\++我就要提一句，VB里面是没有++这个运算符的，但是有+=。要进行加一的操作的话，除了最麻烦的a=a+1，只能a+=1。
我看到有的教程里面Next后面会加一个i，有些又不加，就上网搜索了一下到底是怎么回事。最后得出的结论是加和不加没有区别，加上i是为了兼容过去BASIC的语法。
还有一个有关的内容是VB的等于运算。VB不用==来表示相等比较，而是使用=来表示，同时=也有赋值的含义。那就有问题了，该怎么区分到底是赋值还是相等。网上给出的答案是进行条件判断的时候比如if,for,while的时候就代表等于，其他时候就是赋值。但是我个人认为这并没有从根本上解决问题。试想一下这种情况，Java语言可以做到这样的功能：
```java
int a;
Scanner sc=new Scanner(System.in);
while((a=sc.nextInt())>0) {
	System.out.println(a);
}
sc.close();
```
在while循环中进行一个判断，如果a>0，则输出a；a<0，则跳出循环。但是VB呢，我试了一下这样写：
```vbnet
Dim i As Integer
While ((i = Console.ReadLine()) > 0)
	Console.WriteLine(i)
End While
```
打开隐式转换的警告后，下面会给出这样的提示：
![隐式转换](https://img-blog.csdn.net/20180128203929467?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvYW9wc3R1ZGlv/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
可以看出来，VB仍然将那个赋值式子当作布尔表达式来处理，也就是说=还是等于的意思。我不知道是VB里面不能把一整个表达式和一个值来比较的缘故还是看到for就把=当作等于，反正这个=就不是赋值的意思。