title: VMware虚拟机安装Mac OS和Xcode的过程
date: '2019-07-13 13:11:55'
updated: '2019-07-13 13:26:10'
tags: [VMware, 虚拟机, Unlocker, MacOS]
permalink: /articles/2019/07/13/1562994715860.html
---
最近要上iOS开发技术这门课，但我没有苹果电脑，机房也不让我们用，只能在自己的电脑上装苹果系统。双系统的安装比较复杂，稳定性也不好，还是用最稳妥的在虚拟机上安装的方法。

首先下载安装最新版的VMware Workstation Player（写文章时最新的版本是15），网址如下：[https://www.vmware.com/cn/products/workstation-player/workstation-player-evaluation.html](https://www.vmware.com/cn/products/workstation-player/workstation-player-evaluation.html) 个人使用这款软件是免费的，免去了网上一些死板教程下收费版的VMware Workstation Pro还要破解的过程。

可以先打开VMware Workstation Player看一下，点击创建新虚拟机-稍后安装操作系统，可以看到是没有Mac OS的选项的。![vmware未解锁.png](https://img.hacpai.com/file/2019/07/vmware未解锁-edabf6ce.png)
我们还需要下载一个解锁工具，下载地址如下：[https://github.com/DrDonk/unlocker/releases](https://github.com/DrDonk/unlocker/releases)，这个网站中的内容应该是在不断更新，找最新版本的zip包下载（写文章时最新的版本是3.0.2），解压之后用管理员身份运行**win-install.cmd**文件（注意运行的时候要联网），之后再打开VMware新建虚拟机，就会发现出现了macOS的选项。![vmware解锁.png](https://img.hacpai.com/file/2019/07/vmware解锁-e5df002e.png)
网上的一堆憨批教程都给的是过时版本的下载链接，结果根本装不了新版的macOS，让我走了好大一圈弯路。总之Unlocker的版本最好是最新的，VMware的版本不要太老，就能装新版本的macOS。

之后就要去找macOS的系统镜像文件了。对于公网用户来说，一般相关的贴吧里面会有百度云资源分享。对于教育网用户来说，可以通过教育网PT站来进行下载，强烈推荐蒲公英PT。其实公网也有类似的网站，有兴趣的可以尝试用这种方法找资源，至少速度会比百度云快得多。这个网站给出了很多有价值的内容：[https://www.24ker.com/app/25802.html](https://www.24ker.com/app/25802.html)。

之后就是虚拟机里安装系统的那一套了，和安装Linux系统差不多。在此不再赘述。

安装完毕之后，我兴冲冲地进入App Store找到Xcode，却发现获取按钮是灰色的，可能是系统版本不兼容最新版的Xcode的问题。遇到这种情况也别慌，苹果提供了一些不需要经过App Store的点击即用的Xcode安装包。去这个网站下载即可：[https://developer.apple.com/download/more/](https://developer.apple.com/download/more/)，各种版本的都有，再也不怕兼容性问题了。下载完xip文件后，直接双击，它就会自动解压，解压完成后就可以使用了。