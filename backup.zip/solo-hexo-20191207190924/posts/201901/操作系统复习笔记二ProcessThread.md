title: 操作系统复习笔记（二）——Process & Thread
date: '2019-01-30 19:49:09'
updated: '2019-02-28 18:12:01'
tags: [复习笔记, 操作系统, 进程]
permalink: /articles/2019/01/30/1548848140833.html
---
## Process & thread 1

### 什么是进程 Process

**Process——a program in execution** 一个执行过程中的程序

* Program（executable）：磁盘上的passive实体
* Process：active entity被激活的实体，包含
* 程序计数器
* 栈
* 堆
* 文本
* 数据

#### 什么是程序 Program

一个程序包含

- Code
- Data
- DLLs 动态链接库
- mapped files

Running a program 运行一个程序

* OS创建一个进程，并为它分配内存

Process vs Program

* 两个进程可能和同一个程序相关联
	- 两条单独执行的顺序
	- 文本部分相同，数据、堆、栈都不同

### Process states 进程状态

一个进程执行时，它会改变状态

**基本状态**

- running：指令正在执行
- waiting：进程等待某个事件发生
- ready：进程等待分配给CPU

**扩展状态**

- new：进程被创建
- terminated：进程结束执行

![process states](https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1474977550,2975918179&fm=26&gp=0.jpg)

*为什么waiting之后不能直接running？*

如果有两条队列都能进入running状态，调度很麻烦。同时只有一条队列进入running队列也对所有进程公平。

### Process creation 进程创建

四种典型事件

* 系统初始化
* 用户请求创建
* 系统调用相应接口
	- Unix:fork()
	- Windows:CreateProcess()
* 开启一个批处理任务

### Process hierarchies 进程层次

父进程可以创建子进程，子进程可以继续创建子进程，形成进程树

### Process relationships 进程关系

#### Resource sharing

- 父子进程共享全部资源
- 子进程分享父进程资源的子集
- 父子进程不共享资源

#### Execution

- 父子进程同时执行
- 父进程等子进程结束再执行

#### Address space

- 子进程复制了父进程的地址空间
- 子进程有专门的程序加载地址空间

#### Independent or cooperating

### Process termination 进程结束

- 正常退出（自愿）
- Error exit（自愿）
- Fatal error（强制） 致命错误
- 被其他进程杀死

**Exit 正常退出**

**Abort放弃**

## Process and threads 2

### Data structure of a process

#### Process control block(PCB)进程控制块

和每个进程相关联的信息，包含：

- Process state 进程状态
- Program counter 程序计数器
- CPU register 寄存器：为了能让CPU离开进程后回来还能执行
- CPU scheduling information CPU调度信息
- Memory-management information 内存管理信息
- ~~Account information~~（本课程不学习）
- ~~I/O status information~~（本课程不学习）

### Organization model 进程组织模型

进程被组织成不同的队列

- Ready一条 **<font  color=darkblue>Ready queue</font>**
- New一条 **<font  color=darkblue>Job queue</font>**
- Waiting一条或多条 不同的设备可以放到不同的队列 **<font  color=darkblue>Device queues</font>**

### Process scheduling 进程调度

进程被需要触发的事件驱动，从一条队列转移到另一条队列

#### 调度类型

*  **<font  color=red>Long-term scheduling(or job scheduling)</font> 长程调度**
**<font  color=darkblue>从job queue中选一个到ready queue中</font>**
内存可用时,从磁盘中移出一个到内存
不太频繁，速度慢
*  **<font  color=red>Short-term scheduling(or CPU scheduling)</font> 短程调度**
**<font  color=darkblue>从ready queue中选一个到running</font>**
更加频繁，速度必须快
*  **<font  color=red>Interrupt handling</font> 中断处理**
**<font  color=darkblue>从waiting到ready</font>**
*  **<font  color=red>Medium-term scheduling</font>**
CPU和内存资源管理的混合

**<font  color=darkblue>swapping</font>**：一个进程需要长期等待时，把它先移动到磁盘，把其他进程移入内存

### Scheduling actions

当CPU从一个进程切换到另一个进程时，系统要保存旧进程的状态，加载新进程的状态。这个过程叫 **<font  color=red>上下文切换 context switch</font>**

### 线程 Threads

在进程之间切换越快越好，而创建进程和进程通信工作量很大，所以产生了线程

线程有

* 独立的 <font  color=darkblue>PC, Register, Stack pointer</font>
* 共享的 <font  color=darkblue>Code, Data, File</font>

进程是资源的拥有者

线程用来调度任务

![thread.png](https://i.postimg.cc/nLzGZvsN/thread.png)

#### 超线程和多核

##### 超线程

![hyper-threading](https://i.postimg.cc/sXFFhDRf/hyper-threading.png)

##### 多核

![multicore](https://i.postimg.cc/26nsFRzQ/multicore.png)

#### 两类线程

- 用户线程
用户层级
所有线程在user space中完成

- 内核线程
OS直接执行